<?php
$nim="A22.2019.02739";
$nama='ferisa salsabila p';
echo"NIM : ". $nim ."<br>";
echo"Nama : $nama";
?>