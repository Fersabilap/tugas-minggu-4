<?php
$nim="A22.2019.02739";
$nama='ferisa salsabila p';
$umur=19;
$nilai=82.25;
$status= TRUE;
echo"NIM : " . $nim . "<br>";
echo"Nama : $nama<br>";
print "Umur : ". $umur; print "<br>";
printf ("nilai : %.3f<br>", $nilai);
if ($status)
echo "status : aktif";
else
echo "status : tidak aktif";
?>