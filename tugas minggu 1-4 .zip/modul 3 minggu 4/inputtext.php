<html>
<head><title>Pengolahan Form ~ Text</title></head> 
     <body>
		   <form action="prosestext.php" method="post" 
name="input">
                 Nama Anggota <br>
				 <input type="text" name="nama1"><br> 
				 <input type="text" name="nama2"><br> 
				 <input type="text" name="nama3"><br> 
				 <input type="text" name="nama4"><br> 
				 <input type="submit" name="Input" value="Input">
		    </form>
	 </body>
</html>